import pygame
import constants
import button

start_button = button.Button((constants.WIDTH/2) - 60, constants.HEIGHT/2 - 80, constants.IMAGE_START_BUTTON, 1)
settings_button = button.Button((constants.WIDTH/2) - 60, constants.HEIGHT/2 + 80, constants.IMAGE_SETTINGS_BUTTON, 1)

class Game():
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((constants.WIDTH, constants.HEIGHT))
        pygame.display.set_caption(constants.TITLE)
        self.clock = pygame.time.Clock()
        self.running = True

    def run(self):
        self.running = True
        print("rodando")
        while self.running:
            self.clock.tick(constants.FPS)
            self.screen.blit(constants.IMAGE_BACKGROUND, (0,0))
            if start_button.draw(self.screen):
                print("comecar")
            if settings_button.draw(self.screen):
                print("configuracoes")


            self.events()
        
        self.quit_game()

    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

        pygame.display.update()
    
    def draw_text(self, text, font, color, x, y):
        img = font.render(text, True, color)
        self.screen.blit(img, x, y)

    def quit_game(self):
        print("sair")
        pygame.quit()

    

class Menu(Game):
    def __init__(self):
        pass
    

class Player(Game):
    def __init__(self):
        pass

g = Game()
g.run()